/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author exam
 */
public class MainApp {
    public static void main(String[] args){
        System.out.println("Inside Main");
        
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        MessageService service = context.getBean("messageService",MessageService.class);
        EmailService email=context.getBean("emailService",EmailService.class);
        
        System.out.println(service.getMessage());
        System.out.println(email.sendEmail());
        
    }
}
