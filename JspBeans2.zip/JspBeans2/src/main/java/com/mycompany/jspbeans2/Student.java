/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jspbeans2;

/**
 *
 * @author Pratik
 */
public class Student {
     private String name;
    private int roll;
    
    public Student(){
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public String getName(){
        return this.name;
    }
    
    public int getRoll(){
        return this.roll;
    }   
    
    public void setRoll(int roll){
        this.roll = roll;
    }
    

}
