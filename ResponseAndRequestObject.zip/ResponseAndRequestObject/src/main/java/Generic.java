/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.GenericServlet;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;


/**
 *
 * @author Pratik
 */
public class Generic extends GenericServlet {
@Override
    public void service(ServletRequest sr, ServletResponse sr1) throws ServletException, IOException {
        sr1.setContentType("text/html");
        PrintWriter out = sr1.getWriter();
        out.println("<html><body>");
        out.println("<h2>Response from GenericServlet</h2>");
        out.println("Hello, this is a generic servlet example!");
          out.println("<h1>Pratik Sawant 48</h1>");
          out.println("<h1>This is class/h1>"+sr.getClass());
          out.println("<h1>This is Server Name</h1>" + sr.getServerName());
          out.println("<h1>This is Protocol </h1>" + sr.getProtocol());
          out.println("<h1>This is Content Type</h1>" + sr.getContentType());
        out.println("</body></html>");  
    
    }
    
@Override
public void init() throws ServletException{
    System.out.println("Calling init");
    super.init();
}

@Override
public void destroy(){
    System.out.println("Calling Destroy");
    super.destroy();
}
}

