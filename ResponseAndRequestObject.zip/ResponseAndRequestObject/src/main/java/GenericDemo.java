
import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
     * @author Pratik
 */
public class GenericDemo extends GenericServlet {

 @Override
    public void service(ServletRequest sr, ServletResponse sr1) throws ServletException, IOException {
        sr1.setContentType("text/html");
        PrintWriter out = sr1.getWriter();
        out.println("<html><body>");
        out.println("<h2>Response from GenericServlet</h2>");
        out.println("Hello, this is a generic servlet example!");
          out.println("<h1>Pratik Sawant 48</h1>");
        out.println("</body></html>");    }
    
     @Override
public void init() throws ServletException{
System.out.println("calling init");
super.init();

}


    @Override
public void destroy(){
System.out.println("calling destroy");
super.destroy();
}

}



