/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jdbccurd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Pratik
 */
public class Jdbccurd {

    public static void main(String[] args) {
        String url="jdbc:mysql://localhost:3306/student";
        String userName="root";
        String password="admin";
        String query1="SELECT * FROM student;";
        String query2="update student set student_name='Admin' where age=20;";
        String query3="delete from student where student_name='Emily Davis';";
        
        
        try {
            //Create a Conncetion Object
            Connection conn=DriverManager.getConnection(url,userName,password);
            //Create a statement Object
            Statement st=conn.createStatement();
            
            //Update query 
            int num=st.executeUpdate(query2);
            System.out.println("No of Rows affected :" +num);
            //Delete query 
            int num1=st.executeUpdate(query3);
            System.out.println("No of Rows affected :" +num1);
            
            //Execute Query
            ResultSet rs=st.executeQuery(query1);
            
            while(rs.next()){
                System.out.println(rs.getString("student_id"));
                System.out.println(rs.getString("student_name"));
                
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Jdbccurd.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
